import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def data = jsonSlurper.parseText(body)
    
    def transformedRecords = []
    
    data.d.results.each { employee ->
        def record = [
            'GPID': employee.person_id_external,
            'First Name': employee.first_name,
            'Last Name': employee.last_name,
            'Email Address': employee.email_address,
            'emplStatus': employee.employment_status,
            'employee-class': employee.employee_class,
            'Country': employee.employment_information?.country ?: '',
            'Location': employee.employment_information?.location ?: '',
            'Manager name': employee.employment_information?.manager?.name ?: '',
            'Termination Date': employee.termination_date ?: '',
            'Original Hire Date': employee.hire_date ?: ''
        ]
        transformedRecords.add(record)
    }
    
    def result = new JsonBuilder(transformedRecords)
    message.setBody(result.toString())
    return message
}