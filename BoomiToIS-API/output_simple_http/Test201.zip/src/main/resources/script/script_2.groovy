import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def records = jsonSlurper.parseText(body)
    
    def csvContent = new StringBuilder()
    
    // Add CSV header
    csvContent.append('GPID,First Name,Last Name,Email Address,emplStatus,employee-class,Country,Location,Manager name,Termination Date,Original Hire Date\n')
    
    // Add data rows
    records.each { record ->
        csvContent.append("\"${record['GPID']}\",\"${record['First Name']}\",\"${record['Last Name']}\",\"${record['Email Address']}\",\"${record['emplStatus']}\",\"${record['employee-class']}\",\"${record['Country']}\",\"${record['Location']}\",\"${record['Manager name']}\",\"${record['Termination Date']}\",\"${record['Original Hire Date']}\"\n")
    }
    
    message.setBody(csvContent.toString())
    message.setHeader('Content-Type', 'text/csv')
    message.setHeader('filename', 'employee_data_' + new Date().format('yyyyMMdd_HHmmss') + '.csv')
    return message
}