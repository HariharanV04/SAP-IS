import com.sap.gateway.ip.core.customdev.util.Message
import java.security.Security
import org.bouncycastle.jce.provider.BouncyCastleProvider

def Message processData(Message message) {
    // Add BouncyCastle provider for PGP encryption
    Security.addProvider(new BouncyCastleProvider())
    
    def body = message.getBody(String)
    def filename = message.getHeaders().get('filename')
    
    // Simulate PGP encryption (actual implementation would use PGP libraries)
    def encryptedContent = 'PGP_ENCRYPTED_CONTENT: ' + body
    def encryptedFilename = filename + '.pgp'
    
    message.setBody(encryptedContent)
    message.setHeader('filename', encryptedFilename)
    message.setHeader('Content-Type', 'application/pgp-encrypted')
    
    return message
}